package com.example.ash_mod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraft.item.Item;

@Mod(modid = "ash_mod", name = "Ressetting Sword Mod", version = "1.0")
public class Ash_mod {
    public static Item ressetting_sword;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ressetting_sword = new ItemRessettingSword();
        ForgeRegistries.ITEMS.register(ressetting_sword);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
    }
}