package com.example.ash_mod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemStack;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;

public class ItemRessettingSword extends ItemSword {
    public ItemRessettingSword() {
        super(ToolMaterial.DIAMOND);
        setUnlocalizedName("ressetting_sword");
        setRegistryName("ressetting_sword");
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        BlockPos pos = player.getPosition();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos targetPos = pos.add(x, y, z);
                    IBlockState state = world.getBlockState(targetPos);
                    if (state.getBlock() == Blocks.DIRT) {
                        world.setBlockState(targetPos, Blocks.GRASS.getDefaultState());
                    }
                }
            }
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.getHeldItem(hand));
    }
}